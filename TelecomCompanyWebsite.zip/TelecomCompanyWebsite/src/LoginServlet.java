

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




import com.techm.interfaces.AdminDao;
import com.techm.interfaces.CustomerDao;
import com.techm.implementations.AdminImpl;
import com.techm.implementations.CustomerImpl;
import com.techm.classes.Admin;
import com.techm.classes.Customer;




public class LoginServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	private CustomerDao customerDao;
	private AdminDao adminDao;
	boolean isValid=false;

	public void init(ServletConfig config) throws ServletException
	{
		System.out.println("Login Servlet Init invoked!");
		customerDao=new CustomerImpl();
		adminDao=new AdminImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		session.setMaxInactiveInterval(1000);

		System.out.println("Login Servlet doGet invoked!");

		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String valid=request.getParameter("Q1");
		//String invalid=request.getParameter("Q1");


		if(valid.equalsIgnoreCase("customer"))
		{

			Customer c=new Customer();
			c.setUsername(userName);
			c.setPassword(password);
			isValid=customerDao.validateCustomer(c);
			if(isValid==true)
			{	
				session.setAttribute("sessionCustomer",c);
				System.out.println("Customer logged in!");
				RequestDispatcher rd=request.getRequestDispatcher("customerhome.jsp");
				rd.forward(request, response); //the output of the servlet takes you to a new window!
				//rd.include(request, response);//Output of the servlet is added to the same window!
			}

		}
		else if(valid.equalsIgnoreCase("admin"))
		{
			Admin a=new Admin();
			a.setUsername(userName);
			a.setPassword(password);
			isValid=adminDao.validateAdmin(a);

			if(isValid==true)
			{	
				session.setAttribute("sessionAdmin",a);
				System.out.println("Admin logged in!");
				RequestDispatcher rd=request.getRequestDispatcher("adminhome.jsp");
				rd.forward(request, response); //the output of the servlet takes you to a new window!
				//rd.include(request, response);//Output of the servlet is added to the same window!
			}


			else
			{
				PrintWriter out=response.getWriter();
				response.setContentType("text/html");
				out.println("<center><h2>Error during login!</h2>");

				out.println("<h2>Please try again!</h2></center>");

				RequestDispatcher rd=request.getRequestDispatcher("/homepage.jsp");
				rd.include(request,response );
			}

		}	



	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
