package com.techm.interfaces;

import java.util.ArrayList;

import com.techm.classes.Customer;
import com.techm.classes.Bill;
import com.techm.classes.Plan;
public interface BillDao {
	
	public void addPlans(Customer customer,String options[]);
	public void removePlans(Customer customer, String[] options);
}
