package com.techm.interfaces;

import com.techm.classes.Admin;



public interface AdminDao {
	
	public boolean validateAdmin(Admin admin);
}
