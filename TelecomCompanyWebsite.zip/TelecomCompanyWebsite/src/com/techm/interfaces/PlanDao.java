package com.techm.interfaces;

import java.util.ArrayList;




import com.techm.classes.Plan;

public interface PlanDao {
	
	public ArrayList<Plan> getAllPlans();
	/*public ArrayList<Plan> getPostpaidPlans();*/
	public boolean addPlan(Plan plan);
	public boolean updatePlanCharges(Plan plan);
	public boolean updatePlanDetails(Plan plan);
	public boolean updatePlanValidity(Plan plan);
	public boolean removePlan(Plan plan);
	public Plan getPlan(int planId);
	public boolean updatePlan(Plan plan);
	
	
}
