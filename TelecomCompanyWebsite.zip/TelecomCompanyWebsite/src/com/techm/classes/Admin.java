package com.techm.classes;

public class Admin 
{
	private String Username;
	private String password;
	
	
	
	
	public Admin(String username, String password) {
		super();
		Username = username;
		this.password = password;
	}
	
	
	public Admin() {
		// TODO Auto-generated constructor stub
	}


	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "Admin [Username=" + Username + ", password=" + password + "]";
	}
	
	
	
}
