package com.techm.classes;

import java.util.Date;

public class Bill {
	private long mobileNo;
	private int amount;
	private int status;
	
	
	public Bill(long mobileNo, int amount, int status) {
		super();
		this.mobileNo = mobileNo;
		this.amount = amount;
		this.status = status;
	}
	
	
	
	
	public Bill() {
		// TODO Auto-generated constructor stub
	}




	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	
	
	@Override
	public String toString() {
		return "Bill [mobileNo=" + mobileNo + ", amount=" + amount + ", status="
				+ status + "]";
	}
	
	
	

	
	
	
	

}
