package com.techm.implementations;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Connection;
import com.techm.classes.Plan;
import com.techm.connection.jdbcConnection;
import com.techm.interfaces.PlanDao;

public class PlanImpl implements PlanDao {

	jdbcConnection jcon = new jdbcConnection();
	Connection con;

//customer applicable
public ArrayList<Plan> getAllPlans()
	 {
		String SQL="select * from plan";
		ArrayList<Plan> planList=new ArrayList<Plan>();
		Plan plan=null;
		jcon.getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			while(rs.next())
			{
				plan=new Plan();

				plan.setPlanId(rs.getInt("planid"));
				plan.setPlanType(rs.getString("plantype"));
				plan.setPlanName(rs.getString("planname"));
				plan.setCharges(rs.getDouble("charges"));
				plan.setPlanDetails(rs.getString("plandetails"));
				plan.setValidity(rs.getInt("validity"));

				planList.add(plan);
			}
		} 
		catch (SQLException e) 
		{

			e.printStackTrace();
		}
		finally
		{
			jcon.closeConnection();
		}
		return planList;

	}
	
	
	/*public ArrayList<Plan> getPrepaidPlans() {
		String SQL="select * from plan where plantype like 'prepaid'";
		ArrayList<Plan> planList=new ArrayList<Plan>();
		Plan plan=null;
		jcon.getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			while(rs.next())
			{
				plan=new Plan();

				plan.setPlanId(rs.getInt("planid"));
				plan.setPlanType(rs.getString("plantype"));
				plan.setPlanName(rs.getString("planname"));
				plan.setCharges(rs.getDouble("charges"));
				plan.setPlanDetails(rs.getString("plandetails"));
				plan.setValidity(rs.getInt("validity"));

				planList.add(plan);
			}
		} 
		catch (SQLException e) 
		{

			e.printStackTrace();
		}
		finally
		{
			jcon.closeConnection();
		}
		return planList;

	}*/
//admin applicable
	public boolean addPlan(Plan plan) {
		String SQL="insert into plan values(?,?,?,?,?,?)";
		boolean isAdded=false;
		jcon.getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setInt(1, plan.getPlanId());
			ps.setString(2, plan.getPlanType());
			ps.setString(3, plan.getPlanName());
			ps.setDouble(4, plan.getCharges());
			ps.setString(5, plan.getPlanDetails());
			ps.setInt(6, plan.getValidity());

			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isAdded=true;
				System.out.println("Plan Added!");
			}
			else
			{
				System.out.println("Plan not Added!");
			}
		} 
		catch (SQLException e) 
		{

			e.printStackTrace();
		}
		finally
		{
			jcon.closeConnection();
		}

		return isAdded;

	}
//admin applicable
	public boolean updatePlanCharges(Plan plan) {
		String SQL="update plan set charges=? where planid=?";
		jcon.getConnection();
		boolean isUpdated=false;
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setDouble(1, plan.getCharges());
			ps.setInt(2,plan.getPlanId());

			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isUpdated=true;
				System.out.println("Plan Updated!");
			}
			else
			{
				System.out.println("Plan not Updated!");
			}
		}	
		catch (SQLException e) 
		{

			e.printStackTrace();
		}
		finally
		{
			jcon.closeConnection();
		}

		return isUpdated;

	}
	//admin applicable
	public boolean updatePlanDetails(Plan plan) {
		String SQL="update plan set details=? where planid=?";
		jcon.getConnection();
		boolean isUpdated=false;
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, plan.getPlanDetails());
			ps.setInt(2,plan.getPlanId());
			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isUpdated=true;
				System.out.println("Plan Updated!");
			}
			else
			{
				System.out.println("Plan not Updated!");
			}
		}	
		catch (SQLException e) 
		{

			e.printStackTrace();
		}
		finally
		{
			jcon.closeConnection();
		}

		return isUpdated;

	}
	//admin applicable
	public boolean updatePlanValidity(Plan plan) {
		String SQL="update plan set validity=? where planid=?";
		jcon.getConnection();
		boolean isUpdated=false;
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setInt(1, plan.getValidity());
			ps.setInt(2,plan.getPlanId());

			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isUpdated=true;
				System.out.println("Plan Updated!");
			}
			else
			{
				System.out.println("Plan not Updated!");
			}
		}	
		catch (SQLException e) 
		{

			e.printStackTrace();
		}
		finally
		{
			jcon.closeConnection();
		}

		return isUpdated;

	}
	//admin applicable
	public boolean removePlan(Plan plan) {
		String SQL="delete from plan where planid=?";
		boolean isRemoved=false;
		jcon.getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setInt(1, plan.getPlanId());
			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isRemoved=true;
				System.out.println("Plan Removed!");
			}
			else
			{
				System.out.println("Plan not removed!");
			}

		} 
		catch (SQLException e) 
		{

			e.printStackTrace();
		}
		finally
		{
			jcon.closeConnection();
		}
		return isRemoved;

	}
	//admin applicable
	public Plan getPlan(int planId) {
		String SQL="select * from plan where planid=?";

		Plan plan=null;
		jcon.getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setInt(1, planId);
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			if(rs.next())
			{
				plan=new Plan();

				plan.setPlanId(Integer.parseInt(rs.getString("planid")));
				plan.setPlanType(rs.getString("plantype"));
				plan.setPlanName(rs.getString("planname"));
				plan.setCharges(Double.parseDouble(rs.getString("charges")));
				plan.setPlanDetails(rs.getString("details"));
				plan.setValidity(Integer.parseInt(rs.getString("validity")));
			}
		} 
		catch (SQLException e) 
		{

			e.printStackTrace();
		}
		finally
		{
			jcon.closeConnection();
		}
		return plan;

	}
	//admin applicable
	public boolean updatePlan(Plan plan) {
		String SQL="update plan set charges=?,details=?,validity=? where planid=?";
		jcon.getConnection();
		boolean isUpdated=false;
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setDouble(1,plan.getCharges());
			ps.setString(2, plan.getPlanDetails());
			ps.setInt(3, plan.getValidity());
			ps.setInt(4, plan.getPlanId());

			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isUpdated=true;
				System.out.println("Plan Updated!");
			}
			else
			{
				System.out.println("Plan not Updated!");
			}
		}	
		catch (SQLException e) 
		{

			e.printStackTrace();
		}
		finally
		{
			jcon.closeConnection();
		}

		return isUpdated;

	}


	

}
