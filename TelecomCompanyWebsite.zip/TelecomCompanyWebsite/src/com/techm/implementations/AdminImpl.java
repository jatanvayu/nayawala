package com.techm.implementations;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.techm.classes.Admin;
import com.techm.connection.jdbcConnection;
import com.techm.interfaces.AdminDao;

public class AdminImpl implements AdminDao{
	
	jdbcConnection jcon = new jdbcConnection();
	Connection con;
	
	
	public boolean validateAdmin(Admin admin) {
		String SQL="select * from admin where username=? and password=?";
		boolean isValid=false;
		jcon.getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, admin.getUsername());
			ps.setString(2, admin.getPassword());
			ResultSet rs=ps.executeQuery();
			//validation 
			if(rs.next())
			{
				isValid=true;
			}
			
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			jcon.closeConnection(); 
		}
		
		return isValid;
		
	}

}
